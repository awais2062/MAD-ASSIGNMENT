import 'package:flutter/material.dart';
import 'package:assignment/pages/home.dart';

void main() {
  runApp(
    const MaterialApp(
      title: 'Car Showroom App',
      home: Home(),
      debugShowCheckedModeBanner: false,
    ),
  );
}
