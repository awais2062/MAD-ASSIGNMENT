import 'package:flutter/material.dart';
import '../Products/product.dart';
import 'details.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  // Create a list of cars
  final List<Product> cars = [
    Product(
      name: 'Tesla Model S',
      image: 'assets/tesla.png',  // Add Tesla car image
      price: 7500000,
      description: 'Electric, stylish, and powerful!',
    ),
    Product(
      name: 'BMW 3 Series',
      image: 'assets/bmw.png',  // Add BMW car image
      price: 4000000,
      description: 'A perfect blend of luxury and performance.',
    ),
    Product(
      name: 'Audi A6',
      image: 'assets/audi.png',  // Add Audi car image
      price: 4500000,
      description: 'Comfort, technology, and performance at its best.',
    ),
    Product(
      name: 'Mercedes-Benz C-Class',
      image: 'assets/mercedes.png',  // Add Mercedes car image
      price: 5500000,
      description: 'Luxury redefined with advanced technology.',
    )
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Car Showroom'),
        backgroundColor: Colors.black87, // Darker theme for a more elegant feel
      ),
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(16.0),
          child: ListView.builder(
            itemCount: cars.length,
            itemBuilder: (context, index) {
              Product car = cars[index];
              return Card(
                child: ListTile(
                  leading: Image.asset(car.image),  // Car image display
                  title: Text(car.name),
                  subtitle: Text('\RS ${car.price}'),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => Details(product: car),
                      ),
                    );
                  },
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
